package org.elsys.todo.interfaces;

public enum Status {
	TODO, DOING, DONE
}
