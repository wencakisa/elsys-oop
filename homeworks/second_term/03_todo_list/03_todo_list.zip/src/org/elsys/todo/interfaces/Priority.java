package org.elsys.todo.interfaces;

public enum Priority {
	HIGH, NORMAL, LOW
}
