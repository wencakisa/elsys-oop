package org.elsys.cardgame.api.operation;

public interface Operation {

	String getName();

	void execute();

}
