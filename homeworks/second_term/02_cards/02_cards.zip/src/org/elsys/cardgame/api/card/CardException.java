package org.elsys.cardgame.api.card;

public class CardException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8822513014262189134L;

}
