package org.elsys.cardgame.api.card;

public interface Card {

	Suit getSuit();

	Rank getRank();
}
